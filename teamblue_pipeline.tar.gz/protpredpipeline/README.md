# Protein Prediction Pipeline
This Protein Prediction Pipeline (PPP, or ProtPred) is a project made by Anagha Anil, Andrew Lutsky, Manjot Nagyal, and Jonathan Zhu for the course 03-713 Bioinformatics Data Integration Practicum at Carnegie Mellon University. The pipeline takes in FASTA files for proteins and analyzes them on the level of tertiary structure. 

Please consult the manual located in this repository for detailed instructions for use.
